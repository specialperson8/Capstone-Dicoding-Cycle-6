
<?php $__env->startSection('content-register'); ?>
    <div class="form-container">
        <form class="register-form">
            <h2>Register</h2>
            <h5>Buat akun baru untuk mengakses aplikasi</h5>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="login-link">
                Sudah memiliki akun? <a href="login.html">Login disini</a>
            </div>
            <button type="submit">Sign Up</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.utama-reg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dicoding\capstone\capstone-dicoding\resources\views/register.blade.php ENDPATH**/ ?>