
<?php $__env->startSection('content-login'); ?>
    <div class="form-container">
        <form class="register-form">
            <h2>Login</h2>
            <h5>Selamat datang kembali, silakan masukkan detail Anda!</h5>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="login-link">
                Belum memiliki akun? <a href="register.html">Daftar disini</a>
            </div>
            <button type="submit">Masuk</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.utama-loginreg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dicoding\capstone\capstone-dicoding\resources\views/login.blade.php ENDPATH**/ ?>