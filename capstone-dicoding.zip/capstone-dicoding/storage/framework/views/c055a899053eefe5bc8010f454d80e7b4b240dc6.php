<nav>
    <div class="logo">
        <img src="<?php echo e(asset('front/assets/infoBeasiswa/Logo.png')); ?>" alt="Logo NemuBeasiswa">
    </div>
    <ul id="menuList">
        <li><a href="<?php echo e(url('home')); ?>">Home</a></li>
        <li><a href="#">Scholarship</a></li>
        <li><a href="#">Favorite</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
        <li><a href="<?php echo e(url('register')); ?>" class="active">Sign Up</a></li>
    </ul>
    <div class="menu-icon">
        <i class="fa-solid fa-bars" onclick="toggleMenu()"></i>
    </div>
</nav>
<?php /**PATH E:\dicoding\capstone\capstone-dicoding\resources\views/layouts/front/include/header-reg.blade.php ENDPATH**/ ?>