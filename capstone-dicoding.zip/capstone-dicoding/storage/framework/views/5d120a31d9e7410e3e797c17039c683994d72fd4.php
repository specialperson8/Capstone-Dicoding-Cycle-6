<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/styles.css')); ?>">
</head>

<body>
    <!--  Header -->
    <?php $__env->startSection('header'); ?>
        <?php echo $__env->make('layouts.front.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <!-- Batas Header -->
    
    <?php echo $__env->yieldContent('content'); ?>

    
    <!-- end of main -->
    <!--footer -->
    <?php $__env->startSection('footer'); ?>
        <?php echo $__env->make('layouts.front.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldSection(); ?>
    <!-- end of footer -->
    <script src="main.js"></script>

</body>

</html>
<?php /**PATH E:\dicoding\capstone\capstone-dicoding\resources\views/layouts/front/utama.blade.php ENDPATH**/ ?>