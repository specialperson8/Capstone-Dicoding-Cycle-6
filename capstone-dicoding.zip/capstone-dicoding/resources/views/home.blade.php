@extends('layouts.front.utama')
@section('content')
    <div class="banner">
        <div class="banner-left">
            <h1>
                KAMI TELAH MENEMUKAN<br>
                <span style="color: #FFC436;">BEASISWA</span> YANG <span style="color: #337CCF;">COCOK</span> <br>
                DENGAN ANDA.
            </h1>

            <p>
                Dapatkan beasiswa gratis untuk setiap jenjang pendidikan yang bisa <br>
                didapatkan oleh setiap pelajar yang berprestasi untuk masa depan cerah
            </p>
            <P class="p1">
                Pencarian Beasiswa Cepat
            </P>
        </div>

        <div class="banner-right">
            <div class="wrapper">
                <div class="image_1">
                    <img src="{{ asset('front/assets/Images/image_1.png') }}" alt=""
                        style="height:530px;width: 550px ;">
                </div>

                <div class="background">
                    <img src="{{ asset('front/assets/Vectors/yellow-rectangle.png') }}" alt="">
                </div>
                <div class="line-wrap">
                    <img src="{{ asset('front/assets/Vectors/rectangle.png') }}" alt="" style="height:700px;">
                </div>
            </div>
        </div>
    </div>

    <div class="main-banner-menu">
        <ul>
            <li>
                <select class="dropdown">
                    <option value="">Tingkat Studi</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA">SMA</option>
                    <option value="S1">S1</option>
                    <option value="S2">S2</option>
                    <option value="S3">S3</option>
                </select>
            </li>
            <li>
                <input type="text" class="input-field" placeholder="Pilih Prodi">
            </li>
            <li>
                <a href="#" class="btn yellow">Search</a>
            </li>
        </ul>
        <div class="background"></div>
    </div>

    <!-- End of Banner -->

    <div class="main-about-us">
        <div class="left">
            <h2>About Us</h2>
            <div class="wrapper-img">
                <img src="{{ asset('front/assets/Images/rangkap.png') }}" alt="Image 1">
            </div>
        </div>

        <div class="right">
            <p>
                Selamat datang di NemuBeasiswa, platform yang bertujuan untuk membantu Anda dalam mencari informasi
                beasiswa dengan mudah dan efisien. <br><br>
                Kami percaya bahwa akses terhadap pendidikan tinggi seharusnya tidak menjadi hambatan finansial bagi
                siapapun. Oleh karena itu, kami telah menciptakan NemuBeasiswa sebagai sumber daya informasi yang
                terpusat, mudah diakses, dan komprehensif bagi para pencari beasiswa di seluruh <br><br>
                Tujuan utama kami adalah memberikan platform yang mudah dinavigasi dan terstruktur dengan baik, sehingga
                Anda dapat dengan cepat menemukan informasi tentang berbagai macam beasiswa yang tersedia. Mulai dari
                persyaratan, tenggat waktu, hingga proses aplikasi, semua informasi yang Anda butuhkan tersedia di sini.
                <br><br>
                Bergabunglah dengan kami sekarang dan mulailah perjalanan Anda menuju masa depan yang cerah dan penuh
                prestasi!
            </p>
        </div>
    </div>

    <!-- End of about us section -->


    <div class="main-beasiswa">
        <div class="main-beasiswa1">
            <h2>Beasiswa Sekolah Dasar</h2>
            <a href="#" class="btn yellow">Lihat semuanya</a>
            <ul>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_127.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_128.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_129.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_130.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_131.jpeg') }}" alt="">
                </li>
            </ul>
        </div>

        <div class="main-beasiswa2">
            <h2>Beasiswa Sekolah Menengah Pertama</h2>
            <a href="#" class="btn yellow">Lihat semuanya</a>
            <ul>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_127.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_128.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_129.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_130.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_131.jpeg') }}" alt="">
                </li>
            </ul>
        </div>

        <div class="main-beasiswa3">
            <h2>Beasiswa Sekolah Menengah Atas</h2>
            <a href="#" class="btn yellow">Lihat semuanya</a>
            <ul>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_127.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_128.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_129.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_130.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_131.jpeg') }}" alt="">
                </li>
            </ul>
        </div>

        <div class="main-beasiswa4">
            <h2>Beasiswa D3</h2>
            <a href="#" class="btn yellow">Lihat semuanya</a>
            <ul>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_127.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_128.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_129.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_130.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_131.jpeg') }}" alt="">
                </li>
            </ul>
        </div>

        <div class="main-beasiswa5">
            <h2>Beasiswa S1 / D4</h2>
            <a href="#" class="btn yellow">Lihat semuanya</a>
            <ul>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_127.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_128.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_129.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_130.jpeg') }}" alt="">
                </li>
                <li>
                    <img src="{{ asset('front/assets/Images/rectangle_131.jpeg') }}" alt="">
                </li>
            </ul>
        </div>
    </div>
    <!-- end of main beasiswa -->

    <div class="berita">
        <div class="berita__judul">
            <h2>Berita Terbaru</h2>
        </div>
        <div class="berita__container">
            <ul>
                <li class="berita__item">
                    <img src="{{ asset('front/assets/Images/rectangle_136.jpeg') }}" alt=""
                        style="width: 380px;height: 477px;">
                </li>
                <li class="berita__item">
                    <img src="{{ asset('front/assets/Images/rectangle_137.jpeg') }}" alt=""
                        style="width: 380px;height: 477px;">
                </li>
                <li class="berita__item">
                    <img src="{{ asset('front/assets/Images/rectangle_138.jpeg') }}" alt=""
                        style="width: 380px;height: 477px;">
                </li>
            </ul>
        </div>
    </div>

    <!-- end of main berita -->

    <div class="tutorial">
        <div class="tutorial__section">
            <h2>Bagaimana mencocokkan diri Anda dengan beasiswa</h2>
            <div class="tutorial__content">
                <div class="tutorial__left">
                    <section class="tutorial__box tutorial__box--left">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang1.png') }}" alt="Icon Image 1"
                                style="height: 101px;width: 135px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Daftar Gratis</h3>
                        </section>
                    </section>
                    <div class="tutorial__chain">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                    </div>
                    <section class="tutorial__box tutorial__box--left">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang2.png') }}" alt="Icon Image 2"
                                style="height: 110px;width: 78px;margin-left: 20px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Anda Cocok</h3>
                        </section>
                    </section>
                    <div class="tutorial__chain">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                    </div>
                    <section class="tutorial__box tutorial__box--left">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang3.png') }}" alt="Icon Image 3"
                                style="height: 110px;width: 95px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Simpan dan<br>Ajukan Permohonan</h3>
                        </section>
                    </section>
                </div>
                <div class="tutorial__right">
                    <img src="{{ asset('front/assets/Vectors/orang4.png') }}" alt="Right Image"
                        style="height: 310px;width: 427px;margin-top: 171px;margin-bottom: 8 0px;">
                    <a href="#" class="btn  yellow">Mulai hari ini</a>
                </div>
            </div>
        </div>
        <!-- end of tutorial 1 -->

        <div class="tutorial__section">
            <h2>Bagaimana Anda dapat menginformasikan beasiswa baru</h2>
            <div class="tutorial__content">
                <div class="tutorial__left">
                    <img src="{{ asset('front/assets/Vectors/orang5.png') }}" alt="Left Image"
                        style="height: 302px;width: 479px;margin-top: 171px;margin-bottom: 80px;">
                    <a href="#" class="btn yellow">Mulai hari ini</a>
                </div>
                <div class="tutorial__right">
                    <section class="tutorial__box tutorial__box--right">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang1.png') }}" alt="Icon Image 1"
                                style="height: 101px;width: 135px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Daftar Gratis</h3>
                        </section>
                    </section>
                    <div class="tutorial__chain">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                    </div>
                    <section class="tutorial__box tutorial__box--right">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang2.png') }}" alt="Icon Image 2"
                                style="height: 110px;width: 78px;margin-left: 20px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Isi Form Detail Beasiswa</h3>
                        </section>
                    </section>
                    <div class="tutorial__chain">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                        <img src="{{ asset('front/assets/Vectors/Chain.png') }}" alt="Chain Image">
                    </div>
                    <section class="tutorial__box tutorial__box--right">
                        <section class="tutorial__icon tutorial__icon--left">
                            <img src="{{ asset('front/assets/Vectors/orang3.png') }}" alt="Icon Image 3"
                                style="height: 110px;width: 95px;">
                        </section>
                        <section class="tutorial__text tutorial__text--right">
                            <h3>Ajukan dan Tunggu<br>Validasi Admin</h3>
                        </section>
                    </section>
                </div>
            </div>
        </div>
        <!-- end of tutorial 2 -->
    </div>
    <!-- end of tutorial -->


    <div class="faq-section">
        <h2>Frequently Asked Questions</h2>

        <div class="faq-content-wrap">
            <div class="faq-image">
                <img src="{{ asset('front/assets/Images/orang6.png') }}" alt="FAQ Image"
                    style="width: 322px;height: 483px;">
            </div>
            <div class="faq-questions">
                <ul>
                    <li>
                        <select class="dropdown">
                            <option value="">Apa itu NemuBeasiswa?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                    <li>
                        <select class="dropdown">
                            <option value="">Apakah penggunaan NemuBeasiswa gratis?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                    <li>
                        <select class="dropdown">
                            <option value="">Bagaimana cara saya mencari beasiswa yang sesuai dengan saya di
                                NemuBeasiswa?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                    <li>
                        <select class="dropdown">
                            <option value="">Apakah NemuBeasiswa menyediakan informasi tentang beasiswa untuk
                                semua
                                tingkat pendidikan?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                    <li>
                        <select class="dropdown">
                            <option value="">Apakah NemuBeasiswa menjamin penerimaan beasiswa?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                    <li>
                        <select class="dropdown">
                            <option value="">Bagaimana cara saya mengupload beasiswa baru?</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                            <option value="a">a</option>
                        </select>
                    </li>
                </ul>
            </div>
        </div>

        <div class="faq-contact-box">
            <div class="contact-info">
                <h2>Masih memiliki pertanyaan?</h2>
            </div>
            <div class="contact-action">
                <a href="#" class="btn yellow">Contact Us</a>
            </div>
        </div>
    </div>
    <div class="faq-bottom">
        <h2>Mencari dan Mendaftar beasiswa seharusnya mudah dengan </h2>
        <a href="{{ url('home') }}" class="faq-logo"><img src="{{ asset('front/assets/Vectors/Logo 2.png') }}"
                alt="Logo"></a>
    </div>
@endsection
