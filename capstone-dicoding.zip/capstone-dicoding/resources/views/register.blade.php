@extends('layouts.front.utama-reg')
@section('content-register')
    <div class="form-container">
        <form class="register-form">
            <h2>Register</h2>
            <h5>Buat akun baru untuk mengakses aplikasi</h5>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="login-link">
                Sudah memiliki akun? <a href="login.html">Login disini</a>
            </div>
            <button type="submit">Sign Up</button>
        </form>
    </div>
@endsection
