<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('front/css/styles.css') }}">
</head>

<body>
    <!--  Header -->
    @section('header')
        @include('layouts.front.include.header')
    @show
    <!-- Batas Header -->
    {{-- content --}}
    @yield('content')

    {{-- end content --}}
    <!-- end of main -->
    <!--footer -->
    @section('footer')
        @include('layouts.front.include.footer')
    @show
    <!-- end of footer -->
    <script src="main.js"></script>

</body>

</html>
