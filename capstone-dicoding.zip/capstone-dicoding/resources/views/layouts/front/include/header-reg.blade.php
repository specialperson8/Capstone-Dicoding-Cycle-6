<nav>
    <div class="logo">
        <img src="{{ asset('front/assets/infoBeasiswa/Logo.png') }}" alt="Logo NemuBeasiswa">
    </div>
    <ul id="menuList">
        <li><a href="{{ url('home') }}">Home</a></li>
        <li><a href="#">Scholarship</a></li>
        <li><a href="#">Favorite</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="{{ url('login') }}">Login</a></li>
        <li><a href="{{ url('register') }}" class="active">Sign Up</a></li>
    </ul>
    <div class="menu-icon">
        <i class="fa-solid fa-bars" onclick="toggleMenu()"></i>
    </div>
</nav>
