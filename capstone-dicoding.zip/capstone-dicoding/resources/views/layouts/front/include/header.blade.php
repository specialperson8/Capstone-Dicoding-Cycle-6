<header>
    <div class="main-menu">
        <div class="container">
            <nav>
                <div class="logo">
                    <a href="#"><img src="{{ asset('front/assets/Vectors/Logo.png') }}" alt="Logo NemuBeasiswa"></a>
                </div>
                <ul>
                    <li>
                        <a href="{{ url('home') }}" style="color: #FFC436;">Home</a>
                    </li>
                    <li>
                        <a href="#">Scholarship</a>
                    </li>
                    <li>
                        <a href="#">Favorite</a>
                    </li>
                    <li>
                        <a href="#">About Us</a>
                    </li>
                    <li>
                        <a href="{{ url('login') }}" class="btn transparent">Login</a>
                    </li>
                    <li>
                        <a href="{{ url('register') }}" class="btn yellow">Sign up</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
