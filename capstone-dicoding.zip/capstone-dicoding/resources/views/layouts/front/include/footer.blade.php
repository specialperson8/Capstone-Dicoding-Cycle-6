<section class="footer">
    <div class="footer-information">
        <img src="{{ asset('front/assets/Vectors/Logo.png') }}" alt="">
        <p>
            NemuBeasiswa sebagai sumber daya <br>
            informasi yang terpusat, mudah diakses, dan <br>
            komprehensif bagi para pencari beasiswa di <br>
            seluruh Indonesia.
        </p>
    </div>

    <div class="footer-link">
        <h2>Useful link</h2>
        <ul>
            <li>
                <a href="#">Login</a>
            </li>
            <li>
                <a href="#">for Scholarship Seekers</a>
            </li>
            <li>
                <a href="#">for Admin</a>
            </li>
            <li>
                <a href="#">About Us</a>
            </li>
            <li>
                <a href="#">Contact Us</a>
            </li>
        </ul>
    </div>

    <div class="footer-contact-details">
        <h2>Contact Details</h2>
        <ul>
            <li>
                <a href="#">
                    2/669-5 Sample Street,
                    Gedangan, Sidoarjo,
                    Jawa Timur, 62354 - 000 000.
                </a>
            </li>
            <li>
                Sample@gmail.com
            </li>
            <li>
                +62 8123 4567 8900
            </li>
        </ul>
        <img src="{{ asset('front/assets/Vectors/Vector.png') }}" alt="">
        <img src="{{ asset('front/assets/Vectors/Vector1.png') }}" alt="">
        <img src="{{ asset('front/assets/Vectors/vector2.png') }}" alt="">
    </div>
    <div class="footer-copyright">
        <img src="{{ asset('front/assets/Vectors/line.png') }}" alt="">
        <h4>Copyright 2024. All Rights Reserved.</h4>
    </div>
</section>
